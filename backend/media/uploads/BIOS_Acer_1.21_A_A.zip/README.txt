How to update the BIOS: 
Click "B5W1A121.exe" under Winodows mode


Release Note:
1.Update TXE to 3.1.65.2288 for 19H1. 2.Update MCU.